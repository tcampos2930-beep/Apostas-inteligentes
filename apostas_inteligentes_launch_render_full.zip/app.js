// app.js - Apostas Inteligentes backend (Node + sqlite3) with admin token and optional SendGrid confirmation
const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bodyParser = require('body-parser');

const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY || '';
const FROM_EMAIL = process.env.FROM_EMAIL || '';
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'change-this-admin-token';

let sendgrid = null;
if(SENDGRID_API_KEY && FROM_EMAIL){
  try{
    sendgrid = require('@sendgrid/mail');
    sendgrid.setApiKey(SENDGRID_API_KEY);
    console.log('SendGrid enabled for confirmation emails.');
  }catch(e){
    console.warn('SendGrid module not available.', e);
    sendgrid = null;
  }
}

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data.sqlite');
const PORT = process.env.PORT || 3000;

const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) {
    console.error('Could not open database', err);
    process.exit(1);
  }
  console.log('Connected to SQLite database at', DB_PATH);
});

// Ensure leads table exists
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS leads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    confirmed INTEGER DEFAULT 0,
    created_at TEXT NOT NULL
  );`);
});

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.get('/health', (req, res) => res.json({ status: 'ok' }));

// Helper: send confirmation email if SendGrid configured
async function sendConfirmation(email, token){
  if(!sendgrid) return;
  const confirmUrl = `https://your-domain.com/confirm?email=${encodeURIComponent(email)}&token=${encodeURIComponent(token)}`;
  const msg = {
    to: email,
    from: FROM_EMAIL,
    subject: 'Confirme seu e-mail — Apostas Inteligentes',
    text: `Obrigado por se inscrever! Confirme seu e-mail clicando neste link: ${confirmUrl}`,
    html: `<p>Obrigado por se inscrever!</p><p>Clique aqui para confirmar: <a href="${confirmUrl}">${confirmUrl}</a></p>`,
  };
  try{
    await sendgrid.send(msg);
    console.log('Confirmation email sent to', email);
  }catch(err){
    console.error('Error sending confirmation email', err);
  }
}

// Capture lead
app.post('/api/leads', async (req, res) => {
  const { email } = req.body || {};
  if (!email) return res.status(400).json({ success: false, error: 'email required' });
  const createdAt = new Date().toISOString();
  const stmt = db.prepare('INSERT OR IGNORE INTO leads (email, created_at) VALUES (?, ?)');
  stmt.run(email, createdAt, async function(err) {
    if (err) {
      console.error('DB insert error', err);
      return res.status(500).json({ success: false, error: 'db error' });
    }
    if (this.changes === 0) {
      // already existed
      return res.json({ success: true, message: 'email already registered' });
    }
    // Optionally send confirmation email if configured
    if(sendgrid && FROM_EMAIL){
      const token = Buffer.from(email + '|' + createdAt).toString('base64');
      await sendConfirmation(email, token);
    }
    return res.json({ success: true, id: this.lastID });
  });
  stmt.finalize();
});

// List leads (ADMIN endpoint) - protected by x-admin-token header
app.get('/api/leads', (req, res) => {
  const token = req.header('x-admin-token') || '';
  if(token !== ADMIN_TOKEN){
    return res.status(401).json({ success:false, error:'unauthorized' });
  }
  db.all('SELECT id, email, confirmed, created_at FROM leads ORDER BY created_at DESC LIMIT 1000', [], (err, rows) => {
    if (err) return res.status(500).json({ success:false, error:'db error' });
    res.json({ success:true, leads: rows });
  });
});

// Confirmation endpoint for email clicks (simple implementation - marks confirmed)
app.get('/confirm', (req, res) => {
  const { email, token } = req.query || {};
  if(!email || !token) return res.status(400).send('Invalid request');
  // Very basic token check (for MVP only)
  const expected = Buffer.from(email + '|' ).toString('base64').split('|')[0];
  // We'll just set confirmed flag for the email if exists
  db.run('UPDATE leads SET confirmed = 1 WHERE email = ?', [email], function(err){
    if(err) {
      console.error('Error confirming email', err);
      return res.status(500).send('Error confirming');
    }
    return res.send('E-mail confirmado. Obrigado!');
  });
});

// Simple graceful shutdown
process.on('SIGINT', () => {
  console.log('Shutting down...');
  db.close();
  process.exit(0);
});

app.listen(PORT, () => console.log(`Apostas Inteligentes backend listening on ${PORT}`));
