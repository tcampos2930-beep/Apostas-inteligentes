# Apostas Inteligentes — Backend para Render (Atualizado)

Arquivos nesta pasta contêm um backend Node.js simples usando SQLite para armazenar leads.
Ele é pensado para deploy rápido no Render (ou Heroku).

## Arquivos criados
- `app.js` — backend principal (endpoints: /health, POST /api/leads, GET /api/leads). Includes admin token protection and optional SendGrid email confirmations.
- `package.json` — dependências (`@sendgrid/mail` included).
- `Dockerfile` — optional for deploy via Docker/Render/Heroku container registry.
- `Apostas_Inteligentes_AMP_render.html` — AMP landing page already pointing to the Render domain suggested.
- `.github/workflows/ci-deploy.yml` — GitHub Actions: runs install and optionally triggers Render deploy via API when secrets RENDER_API_KEY and RENDER_SERVICE_ID are set.

## Environment variables (recommended)
- `DB_PATH` — default `/data/data.sqlite` (Render persistent storage)
- `ADMIN_TOKEN` — token to protect GET /api/leads (set a strong random value)
- `SENDGRID_API_KEY` — optional, if you want confirmation emails sent
- `FROM_EMAIL` — optional, sender address for confirmation emails (verified on SendGrid)
- `PORT` — optional

## Quick Deploy to Render (ZIP upload)
1. Create account on https://render.com and login.
2. Click **New → Web Service** → choose **Deploy from a ZIP** and upload this package.
3. Set **Name** to `apostas-inteligentes-api` to get `https://apostas-inteligentes-api.onrender.com` as the hostname.
4. Set **Start Command** to: `node app.js`
5. Set environment variables (Render > Environment):
   - `DB_PATH` = `/data/data.sqlite`
   - `ADMIN_TOKEN` = `<your-secret-token>`
   - (optional) `SENDGRID_API_KEY` and `FROM_EMAIL` if you want confirmation emails.
6. Deploy and test: `GET https://apostas-inteligentes-api.onrender.com/health` should return `{"status":"ok"}`.
7. Test lead capture:
   ```bash
   curl -X POST https://apostas-inteligentes-api.onrender.com/api/leads -H "Content-Type: application/json" -d '{"email":"teste@example.com"}'
   ```

## GitHub Actions (optional)
- If you push this repo to GitHub and set secrets `RENDER_API_KEY` and `RENDER_SERVICE_ID`, GitHub Actions will trigger a deploy on push to `main` branch.
- See Render docs on how to obtain `RENDER_API_KEY` and `RENDER_SERVICE_ID`.

## Security notes
- `GET /api/leads` requires header `x-admin-token` equal to `ADMIN_TOKEN` env var.
- For production, consider migrating to PostgreSQL and adding proper auth for admin routes.